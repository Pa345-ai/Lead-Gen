package ch.post.it.evoting.evotinglibraries.toolbox;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

class RaceConditionDiagnosticTest {

    private static final int ITERATIONS = 30; // small, since we print every iteration
    private static final byte[] PARTIAL_DATA = "PARTIAL_VOTE_DATA_BEFORE_FAILURE".getBytes();

    @Test
    @Timeout(value = 60, unit = TimeUnit.SECONDS)
    void diagnoseEveryIterationOutcome() {

        for (int i = 0; i < ITERATIONS; i++) {
            final int iterationNumber = i;
            String outcome;

            try (final OutputToInputStreamConverter converter = new OutputToInputStreamConverter();
                 final InputStream is = converter.convert(os -> {
                     try {
                         os.write(PARTIAL_DATA);
                     } catch (final IOException e) {
                         throw new UncheckedIOException(e);
                     }
                     throw new RuntimeException("Simulated failure for iteration " + iterationNumber);
                 })) {

                byte[] result = is.readAllBytes();
                outcome = "NO_EXCEPTION_ON_READ result.length=" + result.length
                        + " expectedFullLength=" + PARTIAL_DATA.length
                        + " truncated=" + (result.length < PARTIAL_DATA.length);

            } catch (final Throwable t) {
                // Catch EVERYTHING -- Error, IOException, RuntimeException, anything --
                // and report exactly what it was instead of assuming.
                outcome = "THROWN type=" + t.getClass().getName()
                        + " message=" + t.getMessage();
            }

            System.out.println("[ITER " + i + "] " + outcome);
        }
    }
}
