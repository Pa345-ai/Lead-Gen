# Reproduction Steps — Finding A: OutputToInputStreamConverter Exception Swallowing

## Prerequisites
- Java 25 (the library's pom.xml requires this exact version via maven-enforcer-plugin)
- Apache Maven 3.9.11 exactly (the build enforces this version; most package managers ship older Maven, so a manual install is usually needed — see Step 1)
- Git
- Network access to gitlab.com and repo.maven.apache.org

## Step 1 — Install the required Maven version

```bash
cd /opt
wget https://archive.apache.org/dist/maven/maven-3/3.9.11/binaries/apache-maven-3.9.11-bin.tar.gz
tar xzf apache-maven-3.9.11-bin.tar.gz
export PATH=/opt/apache-maven-3.9.11/bin:$PATH
mvn -version   # confirm it reports 3.9.11
```

## Step 2 — Clone the official repository

```bash
cd ~
git clone --depth 1 https://gitlab.com/swisspost-evoting/e-voting/e-voting-libraries.git
```

## Step 3 — Add the diagnostic test file

Save the attached `RaceConditionDiagnosticTest.java` to:

```
~/e-voting-libraries/e-voting-libraries-toolbox/src/test/java/ch/post/it/evoting/evotinglibraries/toolbox/RaceConditionDiagnosticTest.java
```

This file is a standalone JUnit 5 test. It does not modify, reimplement, or mock any part of `OutputToInputStreamConverter` — it instantiates and calls the real, unmodified class directly.

## Step 4 — Run the test

```bash
cd ~/e-voting-libraries
mvn -pl e-voting-libraries-toolbox test \
  -Dtest=RaceConditionDiagnosticTest -DfailIfNoTests=false \
  -DskipHashGeneration=true -Denforcer.skip=true
```

Notes on the flags used:
- `-DskipHashGeneration=true` disables an internal Swiss-Post artifact-hashing Maven profile unrelated to the code under test (its plugin is not published to public Maven repositories and is unrelated to this finding).
- `-Denforcer.skip=true` bypasses a strict Maven-version enforcer rule; this affects only the build tool version check, not the Java compiler target or any compiled code.

Neither flag alters, weakens, or mocks any part of the class being tested.

## Step 5 — Observe the output

Expected console output (exact byte counts and per-iteration THROWN/NO_EXCEPTION_ON_READ outcomes will vary run to run due to genuine thread-scheduling nondeterminism, but a mix of both outcomes should appear):

```
[ITER 0] THROWN type=java.io.IOException message=Simulated failure for iteration 0
...
[ITER 7] NO_EXCEPTION_ON_READ result.length=32 expectedFullLength=32 truncated=false
...
[INFO] BUILD SUCCESS
```

A `NO_EXCEPTION_ON_READ` line for any iteration is, on its own, proof of the defect: it means the writer thread threw an exception that was never observed by the reader, which received the full data as if no failure had occurred.

## What the test does, line by line

For each of 30 iterations:
1. Creates a real `OutputToInputStreamConverter`.
2. Calls `convert()` with a lambda that writes a fixed 32-byte payload, then unconditionally throws a `RuntimeException` — this is the only way a caller can signal failure, since `java.util.function.Consumer.accept()` has no checked-exception signature.
3. Calls `readAllBytes()` on the returned `InputStream` and catches `Throwable` (not just `IOException`), to report exactly what happens without assuming an outcome.
4. Prints either `THROWN type=... message=...` (the safe, expected outcome) or `NO_EXCEPTION_ON_READ result.length=... truncated=...` (the unsafe, bug-triggering outcome).

## Locating the production call site independently

To verify the confirmed production caller referenced in the report:

```bash
git clone --depth 1 https://gitlab.com/swisspost-evoting/e-voting/data-integration-service.git
grep -n "OutputToInputStreamConverter\|XMLSignatureService" \
  data-integration-service/src/main/java/ch/post/it/evoting/dataintegrationservice/pipes/Tools.java
```

This will show the `saveXML()` method described in the report, including the call to `OutputToInputStreamConverter.convert()` and the subsequent call to `XMLSignatureService.genXMLSignature(is, fos, privateKey)` when the object being saved is of type `Configuration.class`.
