# Reproduction Steps — Finding B: Namespace-Prefix Evasion in removeSignatureIfPresent

## Prerequisites
- Java 25
- Apache Maven 3.9.11 exactly
- Git
- Network access to gitlab.com and repo.maven.apache.org

## Step 1 — Install the required Maven version

```bash
cd /opt
wget https://archive.apache.org/dist/maven/maven-3/3.9.11/binaries/apache-maven-3.9.11-bin.tar.gz
tar xzf apache-maven-3.9.11-bin.tar.gz
export PATH=/opt/apache-maven-3.9.11/bin:$PATH
mvn -version   # confirm it reports 3.9.11
```

## Step 2 — Clone the official repositories

This finding's test exercises `XMLSignatureService`, which transitively depends on `crypto-primitives` (a separate Swiss Post repository). Both must be cloned and the latter installed locally first.

```bash
cd ~
git clone --depth 1 https://gitlab.com/swisspost-evoting/e-voting/e-voting-libraries.git
git clone --depth 1 https://gitlab.com/swisspost-evoting/crypto-primitives/crypto-primitives.git
```

## Step 3 — Build and install crypto-primitives locally

```bash
cd ~/crypto-primitives
mvn install -DskipTests -DskipHashGeneration=true -Denforcer.skip=true -Dmdep.skip=true
```

This installs `crypto-primitives-1.5.3.0.jar` (and its `-tests` classifier jar) into your local `~/.m2` repository so that `e-voting-libraries` can resolve it as a dependency.

## Step 4 — Add the test file

Save the attached `NamespaceEvasionAttackTest.java` to:

```
~/e-voting-libraries/e-voting-libraries-protocol-algorithms/src/test/java/ch/post/it/evoting/evotinglibraries/protocol/algorithms/channelsecurity/NamespaceEvasionAttackTest.java
```

This file must live in this exact package to access the package-private `XMLSignatureService`/`GenXMLSignatureAlgorithm`/`VerifyXMLSignatureAlgorithm` classes the same way the library's own existing test (`XMLSignatureServiceTest.java`, in the same directory) does. It does not modify, reimplement, or mock any of these classes — it calls them directly via the real, public `XMLSignatureService` facade.

## Step 5 — Pre-create a placeholder for an internal test-data artifact (build-tooling workaround only)

The full reactor build references a Swiss-Post-internal `testdata` artifact and an antrun task that copies JSON fixtures unrelated to this test. To avoid needing that internal artifact:

```bash
mkdir -p ~/e-voting-libraries/e-voting-libraries-protocol-algorithms/target/test-classes/testdata/protocol-algorithms/json/system-specification

python3 -c "import zipfile; zipfile.ZipFile('/tmp/testdata-1.5.3.0-resources.zip', 'w').close()"
mkdir -p ~/.m2/repository/ch/post/it/evoting/testdata/1.5.3.0
cp /tmp/testdata-1.5.3.0-resources.zip ~/.m2/repository/ch/post/it/evoting/testdata/1.5.3.0/
cat > ~/.m2/repository/ch/post/it/evoting/testdata/1.5.3.0/testdata-1.5.3.0.pom << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <modelVersion>4.0.0</modelVersion>
  <groupId>ch.post.it.evoting</groupId>
  <artifactId>testdata</artifactId>
  <version>1.5.3.0</version>
  <packaging>pom</packaging>
</project>
EOF
```

This step is purely a build-tooling placeholder for an internal fixture-data archive this test does not use; it has no effect on the classes under test.

## Step 6 — Run the test

```bash
cd ~/e-voting-libraries
mvn -pl e-voting-libraries-protocol-algorithms -am test \
  -Dtest=NamespaceEvasionAttackTest -DfailIfNoTests=false \
  -Dsurefire.failIfNoSpecifiedTests=false \
  -DskipHashGeneration=true -Denforcer.skip=true
```

The `-am` flag builds the required dependency modules (`domain`, `xml`) first. `-Dsurefire.failIfNoSpecifiedTests=false` allows modules that don't contain this test class to pass through without error.

## Step 7 — Observe the output

Expected console output (deterministic — should be identical on every run):

```
[CHECK] Real verifyXMLSignature() on untampered original = true

[OBSERVED] Namespace-aware Signature count after resign = 2
    item(0) nodeName=old:Signature
    item(1) nodeName=ds:Signature

[RESULT] verifyXMLSignature(resigned doc, ELECTION AUTHORITY public key) = false
[RESULT] verifyXMLSignature(resigned doc, ATTACKER public key)          = false

[INFO] BUILD SUCCESS
```

## What the test does, step by step

1. Signs an original document (`<choice>CANDIDATE_A</choice>`) using the real `XMLSignatureService.genXMLSignature()`. Confirms via the real `verifyXMLSignature()` that this signature is valid (`true`).
2. Relabels the signature's XML namespace prefix from `ds` to `old`, including the `xmlns:old=` declaration — this is semantically identical, well-formed XML in the same `http://www.w3.org/2000/09/xmldsig#` namespace, just spelled with a different (equally legal) prefix.
3. Modifies the document content to `<choice>CANDIDATE_B</choice>`.
4. Calls the real `genXMLSignature()` again (the library's resign operation) with a second keypair.
5. Independently inspects the result via `getElementsByTagNameNS(...)` to count and identify the `Signature` nodes present.
6. Calls the real `verifyXMLSignature()` on the result, against both the original signer's public key and the second keypair's public key, and prints both results without assuming an outcome in advance.

## Locating the relevant source for manual review

```bash
cat ~/e-voting-libraries/e-voting-libraries-protocol-algorithms/src/main/java/ch/post/it/evoting/evotinglibraries/protocol/algorithms/channelsecurity/GenXMLSignatureAlgorithm.java | grep -n "removeSignatureIfPresent" -A 10

cat ~/e-voting-libraries/e-voting-libraries-protocol-algorithms/src/main/java/ch/post/it/evoting/evotinglibraries/protocol/algorithms/channelsecurity/VerifyXMLSignatureAlgorithm.java | grep -n "extractSignedInfo" -A 6
```

This shows the two methods side by side: the literal-string `getElementsByTagName("ds:Signature")` lookup in the generation/removal path, versus the namespace-aware `getElementsByTagNameNS(XMLSignature.XMLNS, "Signature")` lookup already correctly used in the verification path.
